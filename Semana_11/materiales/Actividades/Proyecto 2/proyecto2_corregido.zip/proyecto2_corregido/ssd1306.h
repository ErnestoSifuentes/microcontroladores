#ifndef SSD1306_H_
#define SSD1306_H_

#include <msp430.h>
#include <stdint.h>

#define SSD1306_I2C_ADDR  0x3C

void I2C_init(void);
void I2C_start_write(uint8_t address);
void I2C_write_byte(uint8_t data);
void I2C_stop(void);

void OLED_command(uint8_t cmd);
void OLED_data(uint8_t data);
void OLED_init(void);
void OLED_clear(void);
void OLED_setCursor(uint8_t page, uint8_t col);
void OLED_writeChar(char c);
void OLED_writeString(const char *str);
void OLED_printTime(unsigned int m, unsigned int s, unsigned int c);

#endif /* SSD1306_H_ */
