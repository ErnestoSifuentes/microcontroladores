#include <msp430.h>
#include "ssd1306.h"

/*
 * Proyecto 2 - Cronometro digital con OLED SSD1306
 * MSP430G2553
 *
 * B0 -> P1.3 : Start / Stop
 * B1 -> P1.4 : Reset
 * B2 -> P1.5 : Lap
 *
 * OLED I2C:
 * P1.6 -> SCL
 * P1.7 -> SDA
 */

#define BTN_START   BIT3
#define BTN_RESET   BIT4
#define BTN_LAP     BIT5

#define DEBOUNCE_DELAY  30000

typedef enum {
    ST_RESET = 0,
    ST_STOPPED,
    ST_RUNNING,
    ST_LAP
} state_t;

volatile state_t state = ST_RESET;

volatile unsigned int cs = 0;
volatile unsigned int sec = 0;
volatile unsigned int min = 0;

volatile unsigned int lap_cs = 0;
volatile unsigned int lap_sec = 0;
volatile unsigned int lap_min = 0;

volatile unsigned char tick_10ms = 0;

void clock_init(void)
{
    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;
}

void gpio_init(void)
{
    /* Botones como entradas con pull-up interno */
    P1DIR &= ~(BTN_START | BTN_RESET | BTN_LAP);
    P1REN |=  (BTN_START | BTN_RESET | BTN_LAP);
    P1OUT |=  (BTN_START | BTN_RESET | BTN_LAP);

    /* Interrupcion por flanco de bajada */
    P1IES |=  (BTN_START | BTN_RESET | BTN_LAP);
    P1IFG &= ~(BTN_START | BTN_RESET | BTN_LAP);
    P1IE  |=  (BTN_START | BTN_RESET | BTN_LAP);
}

void timer_init(void)
{
    /* Interrupcion cada 10 ms con SMCLK = 1 MHz */
    TA0CCTL0 = CCIE;
    TA0CCR0  = 10000 - 1;
    TA0CTL   = TASSEL_2 | MC_1 | TACLR;
}

void reset_time(void)
{
    cs = 0;
    sec = 0;
    min = 0;
}

void capture_lap(void)
{
    lap_cs  = cs;
    lap_sec = sec;
    lap_min = min;
}

void update_time(void)
{
    cs++;

    if (cs >= 100)
    {
        cs = 0;
        sec++;

        if (sec >= 60)
        {
            sec = 0;
            min++;

            if (min >= 100)
            {
                min = 0;
            }
        }
    }
}

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;

    clock_init();
    gpio_init();
    timer_init();

    OLED_init();
    OLED_clear();
    OLED_printTime(0, 0, 0);

    __enable_interrupt();

    while (1)
    {
        if (state == ST_RESET)
        {
            reset_time();
            OLED_printTime(0, 0, 0);
            state = ST_STOPPED;
        }

        if (tick_10ms)
        {
            tick_10ms = 0;

            if (state == ST_RUNNING)
            {
                update_time();
                OLED_printTime(min, sec, cs);
            }
            else if (state == ST_LAP)
            {
                update_time();
                OLED_printTime(lap_min, lap_sec, lap_cs);
            }
        }
    }
}

#pragma vector = TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
    tick_10ms = 1;
}

#pragma vector = PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
    /* Antirrebote simple */
    __delay_cycles(DEBOUNCE_DELAY);

    if ((P1IFG & BTN_START) && !(P1IN & BTN_START))
    {
        if (state == ST_STOPPED)
        {
            state = ST_RUNNING;
        }
        else if (state == ST_RUNNING)
        {
            state = ST_STOPPED;
        }
        else if (state == ST_LAP)
        {
            state = ST_STOPPED;
        }
        P1IFG &= ~BTN_START;
    }

    if ((P1IFG & BTN_RESET) && !(P1IN & BTN_RESET))
    {
        state = ST_RESET;
        P1IFG &= ~BTN_RESET;
    }

    if ((P1IFG & BTN_LAP) && !(P1IN & BTN_LAP))
    {
        if (state == ST_RUNNING)
        {
            capture_lap();
            state = ST_LAP;
        }
        else if (state == ST_LAP)
        {
            state = ST_RUNNING;
        }
        P1IFG &= ~BTN_LAP;
    }
}
