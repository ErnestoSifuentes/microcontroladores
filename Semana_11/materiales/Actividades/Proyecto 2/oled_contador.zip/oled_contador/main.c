#include <msp430.h>
#include "ssd1306.h"

void clock_init(void)
{
    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;
}

void draw_static_screen(void)
{
    OLED_clear();

    OLED_setCursor(1, 40);
    OLED_writeString("HOLA");
}

int main(void)
{
    unsigned int count = 0;

    WDTCTL = WDTPW | WDTHOLD;

    clock_init();
    OLED_init();

    draw_static_screen();
    OLED_printCounter(count);

    while (1)
    {
        __delay_cycles(1000000);

        count++;
        if (count > 100)
        {
            count = 0;
        }

        OLED_printCounter(count);
    }
}
