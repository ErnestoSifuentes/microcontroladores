#include <msp430.h>
#include "ssd1306.h"

void clock_init(void)
{
    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;
}

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;

    clock_init();
    OLED_init();

    while (1)
    {
        OLED_fill(0xFF);
        __delay_cycles(1000000);

        OLED_clear();
        __delay_cycles(1000000);

        OLED_setCursor(2, 20);
        OLED_writeString("12:34.56");
        __delay_cycles(1000000);

        OLED_clear();
        __delay_cycles(1000000);
    }
}
