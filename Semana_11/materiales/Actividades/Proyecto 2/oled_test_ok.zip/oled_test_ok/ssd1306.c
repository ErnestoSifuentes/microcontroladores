#include "ssd1306.h"

#define SSD1306_CMD   0x00
#define SSD1306_DATA  0x40

static const uint8_t font5x7[][5] = {
    /* ' ' */ {0x00,0x00,0x00,0x00,0x00},
    /* '.' */ {0x00,0x60,0x60,0x00,0x00},
    /* '0' */ {0x3E,0x51,0x49,0x45,0x3E},
    /* '1' */ {0x00,0x42,0x7F,0x40,0x00},
    /* '2' */ {0x42,0x61,0x51,0x49,0x46},
    /* '3' */ {0x21,0x41,0x45,0x4B,0x31},
    /* '4' */ {0x18,0x14,0x12,0x7F,0x10},
    /* '5' */ {0x27,0x45,0x45,0x45,0x39},
    /* '6' */ {0x3C,0x4A,0x49,0x49,0x30},
    /* '7' */ {0x01,0x71,0x09,0x05,0x03},
    /* '8' */ {0x36,0x49,0x49,0x49,0x36},
    /* '9' */ {0x06,0x49,0x49,0x29,0x1E},
    /* ':' */ {0x00,0x36,0x36,0x00,0x00}
};

static const uint8_t* getFont(char c)
{
    switch(c)
    {
        case ' ': return font5x7[0];
        case '.': return font5x7[1];
        case '0': return font5x7[2];
        case '1': return font5x7[3];
        case '2': return font5x7[4];
        case '3': return font5x7[5];
        case '4': return font5x7[6];
        case '5': return font5x7[7];
        case '6': return font5x7[8];
        case '7': return font5x7[9];
        case '8': return font5x7[10];
        case '9': return font5x7[11];
        case ':': return font5x7[12];
        default:  return font5x7[0];
    }
}

static void I2C_write2(uint8_t control, uint8_t value)
{
    while (UCB0CTL1 & UCTXSTP);

    UCB0I2CSA = SSD1306_I2C_ADDR;
    UCB0CTL1 |= UCTR | UCTXSTT;

    while ((IFG2 & UCB0TXIFG) == 0);
    UCB0TXBUF = control;
    while ((IFG2 & UCB0TXIFG) == 0);
    UCB0TXBUF = value;
    while ((IFG2 & UCB0TXIFG) == 0);

    UCB0CTL1 |= UCTXSTP;
    while (UCB0CTL1 & UCTXSTP);
}

void I2C_init(void)
{
    P1SEL  |= BIT6 | BIT7;
    P1SEL2 |= BIT6 | BIT7;

    UCB0CTL1 |= UCSWRST;
    UCB0CTL0 = UCMST | UCMODE_3 | UCSYNC;
    UCB0CTL1 = UCSSEL_2 | UCSWRST;
    UCB0BR0  = 10;
    UCB0BR1  = 0;
    UCB0I2CSA = SSD1306_I2C_ADDR;
    UCB0CTL1 &= ~UCSWRST;
}

void OLED_command(uint8_t cmd)
{
    I2C_write2(SSD1306_CMD, cmd);
}

void OLED_data(uint8_t data)
{
    I2C_write2(SSD1306_DATA, data);
}

void OLED_setCursor(uint8_t page, uint8_t col)
{
    OLED_command(0xB0 | page);
    OLED_command(0x00 | (col & 0x0F));
    OLED_command(0x10 | ((col >> 4) & 0x0F));
}

void OLED_clear(void)
{
    uint8_t page, col;
    for (page = 0; page < 8; page++)
    {
        OLED_setCursor(page, 0);
        for (col = 0; col < 128; col++)
        {
            OLED_data(0x00);
        }
    }
}

void OLED_fill(uint8_t value)
{
    uint8_t page, col;
    for (page = 0; page < 8; page++)
    {
        OLED_setCursor(page, 0);
        for (col = 0; col < 128; col++)
        {
            OLED_data(value);
        }
    }
}

void OLED_writeChar(char c)
{
    uint8_t i;
    const uint8_t *glyph = getFont(c);

    for (i = 0; i < 5; i++)
    {
        OLED_data(glyph[i]);
    }
    OLED_data(0x00);
}

void OLED_writeString(const char *str)
{
    while (*str)
    {
        OLED_writeChar(*str++);
    }
}

void OLED_printTime(unsigned int m, unsigned int s, unsigned int c)
{
    char buf[10];
    uint8_t i;

    buf[0] = '0' + ((m / 10) % 10);
    buf[1] = '0' + (m % 10);
    buf[2] = ':';
    buf[3] = '0' + ((s / 10) % 10);
    buf[4] = '0' + (s % 10);
    buf[5] = '.';
    buf[6] = '0' + ((c / 10) % 10);
    buf[7] = '0' + (c % 10);
    buf[8] = '\0';

    OLED_setCursor(2, 20);
    for (i = 0; i < 80; i++)
    {
        OLED_data(0x00);
    }

    OLED_setCursor(2, 20);
    OLED_writeString(buf);
}

void OLED_init(void)
{
    I2C_init();
    __delay_cycles(100000);

    OLED_command(0xAE);
    OLED_command(0xD5); OLED_command(0x80);
    OLED_command(0xA8); OLED_command(0x3F);
    OLED_command(0xD3); OLED_command(0x00);
    OLED_command(0x40);
    OLED_command(0x8D); OLED_command(0x14);
    OLED_command(0x20); OLED_command(0x00);
    OLED_command(0xA1);
    OLED_command(0xC8);
    OLED_command(0xDA); OLED_command(0x12);
    OLED_command(0x81); OLED_command(0xFF);
    OLED_command(0xD9); OLED_command(0xF1);
    OLED_command(0xDB); OLED_command(0x40);
    OLED_command(0xA4);
    OLED_command(0xA6);
    OLED_command(0x2E);
    OLED_command(0xAF);

    OLED_clear();
}
