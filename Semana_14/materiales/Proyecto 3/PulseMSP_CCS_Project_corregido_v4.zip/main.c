#include <msp430.h>
#include <stdint.h>
#include "ssd1306.h"

/* =========================
   Configuración del sistema
   ========================= */
#define SAMPLE_PERIOD_MS        10u     // 100 Hz
#define REFRACTORY_MS           300u    // Evita dobles conteos
#define HYSTERESIS              40u
#define DEFAULT_THRESHOLD       600u

#define LED_BEAT                BIT0    // P1.0
#define BTN_MODE                BIT0    // P2.0
#define BTN_UP                  BIT1    // P2.1
#define BTN_DOWN                BIT2    // P2.2

/* ADC: Sensor de pulso en A4 = P1.4
   Nota: se evita A3/P1.3 porque en la LaunchPad está asociado al botón S2. */
#define PULSE_ADC_CHANNEL       INCH_4
#define PULSE_ADC_AE_BIT        BIT4

typedef enum
{
    ST_BOOT = 0,
    ST_WAIT_SIGNAL,
    ST_MONITOR,
    ST_CONFIG
} system_state_t;

/* =========================
   Variables globales
   ========================= */
volatile uint32_t g_ms = 0;
volatile uint8_t  g_sample_flag = 0;
volatile uint8_t  g_oled_flag = 0;
volatile uint8_t  g_uart_flag = 0;
volatile uint8_t  g_button_event = 0;
volatile uint32_t g_last_button_ms = 0;

volatile uint16_t g_adc_raw = 0;
volatile uint8_t  g_new_sample = 0;
volatile uint8_t  g_peak = 0;
volatile uint16_t g_bpm = 0;
volatile uint16_t g_threshold = DEFAULT_THRESHOLD;
volatile uint32_t g_last_peak_ms = 0;
volatile uint16_t g_last_ibi_ms = 0;
volatile uint8_t  g_above_threshold = 0;

system_state_t g_state = ST_BOOT;

/* Sin buffer de gráfica: el MSP430G2553 solo tiene 512 bytes de RAM. */

/* =========================
   Prototipos
   ========================= */
void clock_init_1MHz(void);
void gpio_init(void);
void uart_init(void);
void uart_tx(char c);
void uart_tx_string(const char *s);
void uart_tx_u16(uint16_t n);
void uart_tx_plot_line(uint16_t sample, uint8_t peak, uint16_t bpm);

void adc_init(void);
void adc_start(void);

void timer_init(void);
void buttons_init(void);

void app_process_sample(uint16_t sample);
void app_handle_buttons(void);
void app_update_state(void);
void app_draw_oled(void);
void app_draw_oled_static(void);

void oled_print_state(system_state_t st);

/* =========================
   Inicialización
   ========================= */
void clock_init_1MHz(void)
{
    if (CALBC1_1MHZ == 0xFF) while (1);
    DCOCTL = 0;
    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;
}

void gpio_init(void)
{
    /* Inicialización básica para evitar entradas flotantes.
       Los periféricos habilitan después sus propios pines. */
    P1DIR = 0x00;
    P1OUT = 0x00;
    P1REN = 0x00;

    P2DIR = 0x00;
    P2OUT = 0x00;
    P2REN = 0x00;

    P3DIR = 0xFF;
    P3OUT = 0x00;

    /* LED de latido */
    P1DIR |= LED_BEAT;
    P1OUT &= ~LED_BEAT;
}

void buttons_init(void)
{
    /* P2.0, P2.1, P2.2 como entradas con pull-up e interrupción */
    P2DIR &= ~(BTN_MODE | BTN_UP | BTN_DOWN);
    P2REN |=  (BTN_MODE | BTN_UP | BTN_DOWN);
    P2OUT |=  (BTN_MODE | BTN_UP | BTN_DOWN);   // pull-up

    P2IES |=  (BTN_MODE | BTN_UP | BTN_DOWN);   // flanco alto->bajo
    P2IFG &= ~(BTN_MODE | BTN_UP | BTN_DOWN);
    P2IE  |=  (BTN_MODE | BTN_UP | BTN_DOWN);
}

void uart_init(void)
{
    /* UART USCI_A0 en P1.1 RX y P1.2 TX */
    P1SEL  |= BIT1 | BIT2;
    P1SEL2 |= BIT1 | BIT2;

    UCA0CTL1 |= UCSWRST;
    UCA0CTL1 |= UCSSEL_2;     // SMCLK = 1 MHz
    UCA0BR0 = 104;            // 1 MHz / 9600
    UCA0BR1 = 0;
    UCA0MCTL = UCBRS0;
    UCA0CTL1 &= ~UCSWRST;
}

void adc_init(void)
{
    ADC10AE0 |= PULSE_ADC_AE_BIT;                 // P1.4 como analógico
    ADC10CTL1 = PULSE_ADC_CHANNEL | ADC10DIV_0 | ADC10SSEL_3; // A4, SMCLK
    ADC10CTL0 = ADC10SHT_2 | ADC10IE | ADC10ON;  // 16 ciclos, interrupción
}

void timer_init(void)
{
    /* Timer_A0 en modo up para 10 ms:
       SMCLK = 1 MHz, divisor /8 => 125 kHz
       10 ms => 1250 cuentas -> CCR0 = 1249
    */
    TA0CCR0  = 1249;
    TA0CCTL0 = CCIE;
    TA0CTL   = TASSEL_2 | ID_3 | MC_1 | TACLR;
}

/* =========================
   UART
   ========================= */
void uart_tx(char c)
{
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = c;
}

void uart_tx_string(const char *s)
{
    while (*s) uart_tx(*s++);
}

void uart_tx_u16(uint16_t n)
{
    char buffer[6];
    uint8_t i = 0;

    if (n == 0)
    {
        uart_tx('0');
        return;
    }

    while (n > 0)
    {
        buffer[i++] = (char)((n % 10u) + '0');
        n /= 10u;
    }

    while (i > 0) uart_tx(buffer[--i]);
}

void uart_tx_plot_line(uint16_t sample, uint8_t peak, uint16_t bpm)
{
    uart_tx_u16(sample);
    uart_tx(',');
    uart_tx_u16((uint16_t)peak);
    uart_tx(',');
    uart_tx_u16(bpm);
    uart_tx('\r');
    uart_tx('\n');
}

/* =========================
   ADC
   ========================= */
void adc_start(void)
{
    g_new_sample = 0;
    ADC10CTL0 &= ~ADC10IFG;
    ADC10CTL0 |= ENC | ADC10SC;
}

/* =========================
   Lógica de aplicación
   ========================= */
void app_process_sample(uint16_t sample)
{
    uint32_t now = g_ms;
    g_peak = 0;
    g_adc_raw = sample;


    if ((sample > g_threshold) && (g_above_threshold == 0))
    {
        if ((now - g_last_peak_ms) > REFRACTORY_MS)
        {
            g_peak = 1;
            P1OUT |= LED_BEAT;

            if (g_last_peak_ms != 0)
            {
                g_last_ibi_ms = (uint16_t)(now - g_last_peak_ms);
                if (g_last_ibi_ms > 0)
                {
                    g_bpm = (uint16_t)(60000u / g_last_ibi_ms);
                }
            }
            g_last_peak_ms = now;
        }
        g_above_threshold = 1;
    }

    if (sample < (uint16_t)(g_threshold - HYSTERESIS))
    {
        g_above_threshold = 0;
    }

    /* LED de latido breve (~30 ms) */
    if ((g_ms - g_last_peak_ms) > 30u)
    {
        P1OUT &= ~LED_BEAT;
    }
}

void app_handle_buttons(void)
{
    uint8_t ev = g_button_event;
    if (ev == 0) return;
    g_button_event = 0;

    switch (ev)
    {
    case BTN_MODE:
        if (g_state == ST_WAIT_SIGNAL) g_state = ST_MONITOR;
        else if (g_state == ST_MONITOR) g_state = ST_CONFIG;
        else if (g_state == ST_CONFIG) g_state = ST_MONITOR;
        break;

    case BTN_UP:
        if (g_state == ST_CONFIG)
        {
            if (g_threshold < 1000u) g_threshold += 10u;
        }
        break;

    case BTN_DOWN:
        if (g_state == ST_CONFIG)
        {
            if (g_threshold > 100u) g_threshold -= 10u;
        }
        break;

    default:
        break;
    }
}

void app_update_state(void)
{
    switch (g_state)
    {
    case ST_BOOT:
        if (g_ms > 1500u)
        {
            g_state = ST_WAIT_SIGNAL;
        }
        break;

    case ST_WAIT_SIGNAL:
        if (g_bpm >= 30u && g_bpm <= 220u)
        {
            g_state = ST_MONITOR;
        }
        break;

    case ST_MONITOR:
        if ((g_ms - g_last_peak_ms) > 3000u)
        {
            g_state = ST_WAIT_SIGNAL;
            g_bpm = 0;
        }
        break;

    case ST_CONFIG:
        break;

    default:
        g_state = ST_BOOT;
        break;
    }
}

void oled_print_state(system_state_t st)
{
    switch (st)
    {
    case ST_BOOT:
        ssd1306_draw_string(0, 0, "PULSEMSP");
        ssd1306_draw_string(0, 10, "Inicializando...");
        break;
    case ST_WAIT_SIGNAL:
        ssd1306_draw_string(0, 0, "PULSEMSP");
        ssd1306_draw_string(0, 10, "Coloque el dedo");
        break;
    case ST_MONITOR:
        ssd1306_draw_string(0, 0, "PULSEMSP");
        ssd1306_draw_string(0, 10, "Monitoreo");
        break;
    case ST_CONFIG:
        ssd1306_draw_string(0, 0, "PULSEMSP");
        ssd1306_draw_string(0, 10, "Config UMBRAL");
        break;
    default:
        ssd1306_draw_string(0, 0, "Estado ?");
        break;
    }
}

void app_draw_oled_static(void)
{
    if (!ssd1306_is_present()) return;
    ssd1306_clear();
    ssd1306_draw_string(0, 0,  "PULSEMSP");
    ssd1306_draw_string(0, 16, "ADC:");
    ssd1306_draw_string(0, 32, "BPM:");
    ssd1306_draw_string(70,16, "TH:");
    ssd1306_draw_string(70,32, "PK:");
}

void app_draw_oled(void)
{
    /* No se limpia toda la pantalla en cada actualización.
       Esto evita bloquear el programa con muchas transacciones I2C. */
    if (!ssd1306_is_present()) return;

    ssd1306_draw_string(30, 16, "     ");
    ssd1306_draw_u16(30, 16, g_adc_raw);

    ssd1306_draw_string(30, 32, "     ");
    ssd1306_draw_u16(30, 32, g_bpm);

    ssd1306_draw_string(88, 16, "     ");
    ssd1306_draw_u16(88, 16, g_threshold);

    if (g_peak) ssd1306_draw_string(94, 32, "SI ");
    else        ssd1306_draw_string(94, 32, "NO ");
}

/* =========================
   main
   ========================= */
int main(void)
{
    uint16_t sample_local = 0;

    WDTCTL = WDTPW | WDTHOLD;

    clock_init_1MHz();
    gpio_init();
    buttons_init();
    uart_init();
    adc_init();

    uart_tx_string("\r\nBOOT PulseMSP\r\n");
    uart_tx_string("Iniciando OLED...\r\n");

    if (ssd1306_init())
    {
        uart_tx_string("OLED detectada\r\n");
        app_draw_oled_static();
    }
    else
    {
        uart_tx_string("OLED NO detectada: revise I2C/direccion/cableado\r\n");
    }

    timer_init();

    __bis_SR_register(GIE);

    while (1)
    {
        if (g_sample_flag)
        {
            g_sample_flag = 0;
            adc_start();
        }

        if (g_new_sample)
        {
            g_new_sample = 0;
            sample_local = g_adc_raw;
            app_process_sample(sample_local);
        }

        app_handle_buttons();
        app_update_state();

        if (g_oled_flag)
        {
            g_oled_flag = 0;
            app_draw_oled();
        }

        if (g_uart_flag)
        {
            g_uart_flag = 0;
            uart_tx_plot_line(g_adc_raw, g_peak, g_bpm);
        }
    }
}

/* =========================
   ISR Timer_A0
   ========================= */
#pragma vector = TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
    static uint8_t uart_div = 0;
    static uint8_t oled_div = 0;

    g_ms += SAMPLE_PERIOD_MS;
    g_sample_flag = 1;

    uart_div++;
    if (uart_div >= 10u)        /* UART cada 100 ms */
    {
        uart_div = 0;
        g_uart_flag = 1;
    }

    oled_div++;
    if (oled_div >= 50u)        /* OLED cada 500 ms */
    {
        oled_div = 0;
        g_oled_flag = 1;
    }
}

/* =========================
   ISR ADC10
   ========================= */
#pragma vector = ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
    g_adc_raw = ADC10MEM;
    g_new_sample = 1;
    ADC10CTL0 &= ~ENC;
}

/* =========================
   ISR Botones puerto 2
   ========================= */
#pragma vector = PORT2_VECTOR
__interrupt void PORT2_ISR(void)
{
    uint32_t now = g_ms;

    if ((now - g_last_button_ms) > 150u)
    {
        if (P2IFG & BTN_MODE) g_button_event = BTN_MODE;
        else if (P2IFG & BTN_UP) g_button_event = BTN_UP;
        else if (P2IFG & BTN_DOWN) g_button_event = BTN_DOWN;

        g_last_button_ms = now;
    }

    P2IFG &= ~(BTN_MODE | BTN_UP | BTN_DOWN);
}
