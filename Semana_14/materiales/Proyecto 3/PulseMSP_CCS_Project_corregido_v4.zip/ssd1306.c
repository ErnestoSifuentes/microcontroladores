#include <msp430.h>
#include <stdint.h>
#include "ssd1306.h"
#include "font5x7.h"

/*
 * Driver SSD1306 sin framebuffer para MSP430G2553.
 * Esta versión usa la misma secuencia I2C del Proyecto 2, que ya fue validada
 * con la OLED: esperar UCB0TXIFG después de START, no esperar UCTXSTT.
 */

#define SSD1306_CMD   0x00
#define SSD1306_DATA  0x40

static uint8_t g_ssd1306_ok = 0;

uint8_t ssd1306_is_present(void)
{
    return g_ssd1306_ok;
}

static void i2c_init(void)
{
    /* USCI_B0 I2C: P1.6 = SCL, P1.7 = SDA */
    P1SEL  |= BIT6 | BIT7;
    P1SEL2 |= BIT6 | BIT7;

    UCB0CTL1 |= UCSWRST;
    UCB0CTL0 = UCMST | UCMODE_3 | UCSYNC;
    UCB0CTL1 = UCSSEL_2 | UCSWRST;

    /* 100 kHz aprox. con SMCLK = 1 MHz, igual que en Proyecto 2 */
    UCB0BR0 = 10;
    UCB0BR1 = 0;

    UCB0I2CSA = SSD1306_ADDR;
    UCB0CTL1 &= ~UCSWRST;
}

static void i2c_start_write(uint8_t address)
{
    while (UCB0CTL1 & UCTXSTP);
    UCB0I2CSA = address;
    UCB0CTL1 |= UCTR | UCTXSTT;
    while ((IFG2 & UCB0TXIFG) == 0);
}

static void i2c_write_byte(uint8_t data)
{
    UCB0TXBUF = data;
    while ((IFG2 & UCB0TXIFG) == 0);
}

static void i2c_stop(void)
{
    UCB0CTL1 |= UCTXSTP;
    while (UCB0CTL1 & UCTXSTP);
}

void ssd1306_command(uint8_t cmd)
{
    i2c_start_write(SSD1306_ADDR);
    i2c_write_byte(SSD1306_CMD);
    i2c_write_byte(cmd);
    i2c_stop();
}

void ssd1306_data_byte(uint8_t data)
{
    i2c_start_write(SSD1306_ADDR);
    i2c_write_byte(SSD1306_DATA);
    i2c_write_byte(data);
    i2c_stop();
}

void ssd1306_set_cursor(uint8_t x, uint8_t page)
{
    if (page > 7) page = 7;
    if (x > 127) x = 127;

    ssd1306_command((uint8_t)(0xB0 | page));
    ssd1306_command((uint8_t)(0x00 | (x & 0x0F)));
    ssd1306_command((uint8_t)(0x10 | ((x >> 4) & 0x0F)));
}

void ssd1306_clear(void)
{
    uint8_t page, col;
    for (page = 0; page < 8; page++)
    {
        ssd1306_set_cursor(0, page);
        for (col = 0; col < 128; col++)
        {
            ssd1306_data_byte(0x00);
        }
    }
}

void ssd1306_update(void)
{
    /* No hace nada: no existe framebuffer. */
}

uint8_t ssd1306_init(void)
{
    i2c_init();
    __delay_cycles(100000);

    g_ssd1306_ok = 1;

    /* Secuencia validada en Proyecto 2 */
    ssd1306_command(0xAE);
    ssd1306_command(0xD5); ssd1306_command(0x80);
    ssd1306_command(0xA8); ssd1306_command(0x3F);
    ssd1306_command(0xD3); ssd1306_command(0x00);
    ssd1306_command(0x40);
    ssd1306_command(0x8D); ssd1306_command(0x14);
    ssd1306_command(0x20); ssd1306_command(0x00);   /* Horizontal addressing, igual que Proyecto 2 */
    ssd1306_command(0xA1);
    ssd1306_command(0xC8);
    ssd1306_command(0xDA); ssd1306_command(0x12);
    ssd1306_command(0x81); ssd1306_command(0xFF);
    ssd1306_command(0xD9); ssd1306_command(0xF1);
    ssd1306_command(0xDB); ssd1306_command(0x40);
    ssd1306_command(0xA4);
    ssd1306_command(0xA6);
    ssd1306_command(0x2E);
    ssd1306_command(0xAF);

    ssd1306_clear();
    return 1u;
}

void ssd1306_draw_char(uint8_t x, uint8_t y, char c)
{
    uint8_t i;
    uint8_t page = y >> 3;

    if (c < 32 || c > 127) c = '?';
    if (x > 122) return;

    ssd1306_set_cursor(x, page);
    for (i = 0; i < 5; i++)
    {
        ssd1306_data_byte(font5x7[(uint8_t)c - 32u][i]);
    }
    ssd1306_data_byte(0x00);
}

void ssd1306_draw_string(uint8_t x, uint8_t y, const char *str)
{
    while (*str && x <= 122)
    {
        ssd1306_draw_char(x, y, *str++);
        x += 6;
    }
}

void ssd1306_draw_u16(uint8_t x, uint8_t y, uint16_t value)
{
    char buf[6];
    uint8_t i = 0;
    uint8_t j = 0;

    if (value == 0)
    {
        ssd1306_draw_char(x, y, '0');
        return;
    }

    while (value > 0 && i < sizeof(buf))
    {
        buf[i++] = (char)((value % 10u) + '0');
        value /= 10u;
    }

    while (i > 0)
    {
        ssd1306_draw_char((uint8_t)(x + j * 6u), y, buf[--i]);
        j++;
    }
}
