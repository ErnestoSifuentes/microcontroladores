#ifndef SSD1306_H_
#define SSD1306_H_

#include <stdint.h>

#define SSD1306_WIDTH   128
#define SSD1306_HEIGHT   64
#define SSD1306_ADDR     0x3C

uint8_t ssd1306_init(void);
uint8_t ssd1306_is_present(void);
void ssd1306_command(uint8_t cmd);
void ssd1306_data_byte(uint8_t data);
void ssd1306_clear(void);
void ssd1306_update(void);                 /* Se conserva por compatibilidad; no usa buffer */
void ssd1306_set_cursor(uint8_t x, uint8_t page);
void ssd1306_draw_char(uint8_t x, uint8_t y, char c);
void ssd1306_draw_string(uint8_t x, uint8_t y, const char *str);
void ssd1306_draw_u16(uint8_t x, uint8_t y, uint16_t value);

#endif
