PulseMSP_CCS_Project_corregido_v3

Cambios principales:
1. La OLED ya no bloquea la UART si no responde por I2C.
2. Se agrega detección rápida de ACK de la pantalla.
3. Si la OLED no se detecta, la UART debe seguir enviando datos cada 10 ms.
4. La OLED se actualiza a 2 Hz y ya no se limpia completa en cada actualización.
5. El bus I2C se configuró a ~50 kHz para hacerlo más tolerante.

Conexiones esperadas:
OLED I2C SSD1306:
VCC -> 3.3 V
GND -> GND
SCL -> P1.6
SDA -> P1.7

Sensor de pulso:
Señal -> P1.4 / A4
VCC -> 3.3 V
GND -> GND

UART:
9600 bps, 8N1, puerto MSP Application UART.
Jumpers RXD/TXD en HW UART.

Si aparece por UART:
OLED NO detectada
entonces el problema no es el programa principal, sino dirección I2C, cableado, alimentación o pull-ups.
