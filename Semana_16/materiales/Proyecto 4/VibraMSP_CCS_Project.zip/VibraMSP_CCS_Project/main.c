
#include <msp430.h>
#include <stdint.h>

#define F_CPU               1000000UL
#define UART_BAUDRATE       9600

#define MPU6050_ADDR        0x68
#define MPU6050_PWR_MGMT_1  0x6B
#define MPU6050_ACCEL_XOUT_H 0x3B

#define SAMPLE_PERIOD_MS    10          // 100 Hz
#define VIB_THRESHOLD_LOW   80
#define VIB_THRESHOLD_HIGH  180

#define BTN_MODE            BIT3        // P1.3 botón integrado LaunchPad
#define BTN_UP              BIT0        // P2.0 botón externo
#define BTN_DOWN            BIT1        // P2.1 botón externo
#define LED_RED             BIT0        // P1.0 LED rojo
#define LED_GREEN           BIT6        // P1.6 no usar si I2C. Se deja libre.
#define LED_STATUS          BIT0        // se usa LED rojo

typedef enum {
    BOOT = 0,
    IDLE,
    MONITOR,
    CONFIG
} system_state_t;

volatile uint8_t sample_flag = 0;
volatile uint16_t ms_ticks = 0;

volatile uint8_t mode_pressed = 0;
volatile uint8_t up_pressed = 0;
volatile uint8_t down_pressed = 0;

system_state_t state = BOOT;

uint16_t vib_low_threshold = VIB_THRESHOLD_LOW;
uint16_t vib_high_threshold = VIB_THRESHOLD_HIGH;

int16_t ax = 0, ay = 0, az = 0;
uint16_t vib = 0;

void clock_init(void);
void gpio_init(void);
void uart_init(void);
void uart_tx_char(char c);
void uart_tx_string(const char *s);
void uart_tx_int(int16_t v);
void uart_tx_uint(uint16_t v);
void uart_tx_csv(int16_t axv, int16_t ayv, int16_t azv, uint16_t vibv);

void i2c_init(void);
void i2c_write_byte(uint8_t dev, uint8_t reg, uint8_t value);
void i2c_read_bytes(uint8_t dev, uint8_t reg, uint8_t *data, uint8_t len);
void mpu6050_init(void);
void mpu6050_read_accel(int16_t *x, int16_t *y, int16_t *z);

void timer_init(void);
uint16_t abs16(int16_t v);
uint16_t vibration_metric(int16_t x, int16_t y, int16_t z);
void update_status_led(uint16_t vibv);

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;

    clock_init();
    gpio_init();
    uart_init();
    i2c_init();
    timer_init();

    __enable_interrupt();

    state = BOOT;
    mpu6050_init();

    uart_tx_string("VibraMSP listo\r\n");
    uart_tx_string("Formato UART: Ax,Ay,Az,Vib\r\n");
    state = IDLE;

    while (1)
    {
        switch (state)
        {
        case IDLE:
            if (mode_pressed) {
                mode_pressed = 0;
                uart_tx_string("Inicio de monitoreo\r\n");
                state = MONITOR;
            }
            break;

        case MONITOR:
            if (mode_pressed) {
                mode_pressed = 0;
                uart_tx_string("Entrando a CONFIG\r\n");
                state = CONFIG;
            }

            if (sample_flag) {
                sample_flag = 0;
                mpu6050_read_accel(&ax, &ay, &az);
                vib = vibration_metric(ax, ay, az);
                update_status_led(vib);
                uart_tx_csv(ax, ay, az, vib);
            }
            break;

        case CONFIG:
            if (mode_pressed) {
                mode_pressed = 0;
                uart_tx_string("Regresando a MONITOR\r\n");
                state = MONITOR;
            }
            if (up_pressed) {
                up_pressed = 0;
                vib_high_threshold += 10;
                uart_tx_string("TH_HIGH=");
                uart_tx_uint(vib_high_threshold);
                uart_tx_string("\r\n");
            }
            if (down_pressed) {
                down_pressed = 0;
                if (vib_high_threshold >= 20) vib_high_threshold -= 10;
                uart_tx_string("TH_HIGH=");
                uart_tx_uint(vib_high_threshold);
                uart_tx_string("\r\n");
            }
            break;

        default:
            state = IDLE;
            break;
        }
    }
}

void clock_init(void)
{
    if (CALBC1_1MHZ == 0xFF) while(1);
    DCOCTL = 0;
    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL = CALDCO_1MHZ;
}

void gpio_init(void)
{
    // LED rojo P1.0
    P1DIR |= LED_RED;
    P1OUT &= ~LED_RED;

    // Botón integrado P1.3
    P1DIR &= ~BTN_MODE;
    P1REN |= BTN_MODE;
    P1OUT |= BTN_MODE;
    P1IES |= BTN_MODE;
    P1IFG &= ~BTN_MODE;
    P1IE  |= BTN_MODE;

    // Botones externos P2.0 y P2.1
    P2DIR &= ~(BTN_UP | BTN_DOWN);
    P2REN |= (BTN_UP | BTN_DOWN);
    P2OUT |= (BTN_UP | BTN_DOWN);
    P2IES |= (BTN_UP | BTN_DOWN);
    P2IFG &= ~(BTN_UP | BTN_DOWN);
    P2IE  |= (BTN_UP | BTN_DOWN);
}

void uart_init(void)
{
    P1SEL  |= BIT1 | BIT2;
    P1SEL2 |= BIT1 | BIT2;

    UCA0CTL1 |= UCSWRST;
    UCA0CTL1 |= UCSSEL_2;        // SMCLK = 1 MHz
    UCA0BR0 = 104;               // 1 MHz / 9600
    UCA0BR1 = 0;
    UCA0MCTL = UCBRS0;           // Modulación recomendada
    UCA0CTL1 &= ~UCSWRST;
}

void uart_tx_char(char c)
{
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = c;
}

void uart_tx_string(const char *s)
{
    while (*s) {
        uart_tx_char(*s++);
    }
}

void uart_tx_int(int16_t v)
{
    uint16_t n;
    char buf[8];
    uint8_t i = 0;

    if (v < 0) {
        uart_tx_char('-');
        n = (uint16_t)(-v);
    } else {
        n = (uint16_t)v;
    }

    if (n == 0) {
        uart_tx_char('0');
        return;
    }

    while (n > 0) {
        buf[i++] = (n % 10) + '0';
        n /= 10;
    }
    while (i > 0) uart_tx_char(buf[--i]);
}

void uart_tx_uint(uint16_t v)
{
    char buf[6];
    uint8_t i = 0;
    if (v == 0) {
        uart_tx_char('0');
        return;
    }
    while (v > 0) {
        buf[i++] = (v % 10) + '0';
        v /= 10;
    }
    while (i > 0) uart_tx_char(buf[--i]);
}

void uart_tx_csv(int16_t axv, int16_t ayv, int16_t azv, uint16_t vibv)
{
    uart_tx_int(axv); uart_tx_char(',');
    uart_tx_int(ayv); uart_tx_char(',');
    uart_tx_int(azv); uart_tx_char(',');
    uart_tx_uint(vibv); uart_tx_string("\r\n");
}

void i2c_init(void)
{
    P1SEL  |= BIT6 | BIT7;
    P1SEL2 |= BIT6 | BIT7;

    UCB0CTL1 |= UCSWRST;
    UCB0CTL0 = UCMST | UCMODE_3 | UCSYNC;   // Maestro I2C síncrono
    UCB0CTL1 = UCSWRST | UCSSEL_2;          // SMCLK
    UCB0BR0 = 10;                           // ~100 kHz con SMCLK=1 MHz
    UCB0BR1 = 0;
    UCB0CTL1 &= ~UCSWRST;
}

void i2c_write_byte(uint8_t dev, uint8_t reg, uint8_t value)
{
    while (UCB0CTL1 & UCTXSTP);
    UCB0I2CSA = dev;
    UCB0CTL1 |= UCTR | UCTXSTT;
    while (!(IFG2 & UCB0TXIFG));
    UCB0TXBUF = reg;
    while (!(IFG2 & UCB0TXIFG));
    UCB0TXBUF = value;
    while (!(IFG2 & UCB0TXIFG));
    UCB0CTL1 |= UCTXSTP;
    while (UCB0CTL1 & UCTXSTP);
}

void i2c_read_bytes(uint8_t dev, uint8_t reg, uint8_t *data, uint8_t len)
{
    uint8_t i;

    while (UCB0CTL1 & UCTXSTP);
    UCB0I2CSA = dev;

    UCB0CTL1 |= UCTR | UCTXSTT;
    while (!(IFG2 & UCB0TXIFG));
    UCB0TXBUF = reg;
    while (UCB0CTL1 & UCTXSTT);

    UCB0CTL1 &= ~UCTR;
    UCB0CTL1 |= UCTXSTT;

    while (UCB0CTL1 & UCTXSTT);

    for (i = 0; i < len; i++) {
        if (i == (len - 1)) {
            UCB0CTL1 |= UCTXSTP;
        }
        while (!(IFG2 & UCB0RXIFG));
        data[i] = UCB0RXBUF;
    }
    while (UCB0CTL1 & UCTXSTP);
}

void mpu6050_init(void)
{
    __delay_cycles(100000);
    i2c_write_byte(MPU6050_ADDR, MPU6050_PWR_MGMT_1, 0x00); // Despertar MPU6050
    __delay_cycles(10000);
}

void mpu6050_read_accel(int16_t *x, int16_t *y, int16_t *z)
{
    uint8_t raw[6];
    i2c_read_bytes(MPU6050_ADDR, MPU6050_ACCEL_XOUT_H, raw, 6);

    *x = (int16_t)((raw[0] << 8) | raw[1]);
    *y = (int16_t)((raw[2] << 8) | raw[3]);
    *z = (int16_t)((raw[4] << 8) | raw[5]);
}

void timer_init(void)
{
    TACCR0 = 10000 - 1;          // 10 ms con SMCLK = 1 MHz
    TACCTL0 = CCIE;
    TACTL = TASSEL_2 | MC_1 | ID_0;  // SMCLK, up mode
}

uint16_t abs16(int16_t v)
{
    return (v < 0) ? (uint16_t)(-v) : (uint16_t)v;
}

uint16_t vibration_metric(int16_t x, int16_t y, int16_t z)
{
    // Métrica simple y didáctica. Se puede ajustar experimentalmente.
    uint32_t sum = (uint32_t)abs16(x) + (uint32_t)abs16(y) + (uint32_t)abs16(z);
    return (uint16_t)(sum / 300U); // Escala reducida para Serial Plotter
}

void update_status_led(uint16_t vibv)
{
    if (vibv >= vib_high_threshold) {
        P1OUT ^= LED_RED;    // vibración alta -> parpadeo
    } else {
        P1OUT &= ~LED_RED;
    }
}

#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A_ISR(void)
{
    sample_flag = 1;
    ms_ticks += SAMPLE_PERIOD_MS;
}

#pragma vector=PORT1_VECTOR
__interrupt void Port_1_ISR(void)
{
    if (P1IFG & BTN_MODE) {
        mode_pressed = 1;
        P1IFG &= ~BTN_MODE;
    }
}

#pragma vector=PORT2_VECTOR
__interrupt void Port_2_ISR(void)
{
    if (P2IFG & BTN_UP) {
        up_pressed = 1;
        P2IFG &= ~BTN_UP;
    }
    if (P2IFG & BTN_DOWN) {
        down_pressed = 1;
        P2IFG &= ~BTN_DOWN;
    }
}
