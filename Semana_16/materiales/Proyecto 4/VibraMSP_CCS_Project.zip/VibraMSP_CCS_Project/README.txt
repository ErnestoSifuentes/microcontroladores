
VibraMSP - Proyecto final de monitoreo de vibraciones con MSP430G2553 + MPU6050

Contenido
- main.c : firmware principal
- README.txt : guía rápida de uso

Función
Lee el acelerómetro MPU6050 por I2C, calcula una métrica simple de vibración y la envía por UART
en formato CSV para visualizarla en Serial Plotter.

Formato de salida UART
Ax,Ay,Az,Vib

Ejemplo:
125,-32,980,64

Conexiones
MPU6050:
VCC -> 3.3 V
GND -> GND
SDA -> P1.7
SCL -> P1.6

UART backchannel LaunchPad:
RX -> P1.1
TX -> P1.2

Botones:
P1.3 -> botón modo (integrado)
P2.0 -> aumentar umbral (externo)
P2.1 -> disminuir umbral (externo)

Estados
BOOT    : inicialización
IDLE    : espera de inicio
MONITOR : adquisición y envío
CONFIG  : ajuste de umbral alto

Uso
1. Programe el MSP430G2553 desde CCS.
2. Abra una terminal serial a 9600 bps o el Serial Plotter.
3. Presione P1.3 para entrar en MONITOR.
4. Observe Ax, Ay, Az y Vib.
5. Presione P1.3 otra vez para entrar en CONFIG.
6. Ajuste el umbral alto con P2.0 y P2.1.
7. Presione P1.3 para volver a MONITOR.

Notas
- La métrica Vib es deliberadamente simple y didáctica.
- Puede mejorarse usando offset en reposo, ventana RMS o un solo eje.
- Si el módulo MPU6050 trae resistencias pull-up en SDA/SCL, normalmente no se requieren externas.
